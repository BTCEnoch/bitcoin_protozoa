/**
 * ui Types
 *
 * @description Type definitions for the ui domain
 */

/**
 * Placeholder interface for ui domain
 * TODO: Replace with actual types
 */
export interface uiConfig {
  // Add configuration properties here
  version: string;
}
