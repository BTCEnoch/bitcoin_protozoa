/**
 * Types for DebugOverlay component
 */
export interface DebugOverlayProps {
  // Define props here
}
