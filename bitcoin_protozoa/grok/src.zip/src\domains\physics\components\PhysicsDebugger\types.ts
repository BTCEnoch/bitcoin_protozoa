/**
 * Types for PhysicsDebugger component
 */
export interface PhysicsDebuggerProps {
  // Define props here
}
