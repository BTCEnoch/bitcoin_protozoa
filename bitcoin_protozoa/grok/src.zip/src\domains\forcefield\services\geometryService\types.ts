/**
 * Types for geometryService service
 */
export interface geometryServiceOptions {
  // Define options here
}
