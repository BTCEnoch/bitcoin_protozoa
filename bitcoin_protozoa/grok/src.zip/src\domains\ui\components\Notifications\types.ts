/**
 * Notifications Types
 *
 * @description Type definitions for Notifications component
 */

export interface NotificationsProps {
  // Component props
}
