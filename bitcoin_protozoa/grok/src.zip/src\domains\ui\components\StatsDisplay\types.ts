/**
 * Types for StatsDisplay component
 */
export interface StatsDisplayProps {
  // Define props here
}
