/**
 * Types for ControlPanel component
 */
export interface ControlPanelProps {
  // Define props here
}
