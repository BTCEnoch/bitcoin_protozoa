/**
 * Types for CreatureContainer component
 */
export interface CreatureContainerProps {
  // Define props here
}
