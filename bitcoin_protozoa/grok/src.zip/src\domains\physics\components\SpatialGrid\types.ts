/**
 * Types for SpatialGrid component
 */
export interface SpatialGridProps {
  // Define props here
}
