/**
 * Types for ForceFieldRenderer component
 */
export interface ForceFieldRendererProps {
  // Define props here
}
