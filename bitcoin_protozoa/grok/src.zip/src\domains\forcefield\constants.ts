/**
 * forcefield Constants
 *
 * @description Constants for the forcefield domain
 */

/**
 * forcefield version
 */
export const _VERSION = '0.1.0';
