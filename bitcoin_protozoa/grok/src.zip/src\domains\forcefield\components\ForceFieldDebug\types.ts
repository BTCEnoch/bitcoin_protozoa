/**
 * ForceFieldDebug Types
 *
 * @description Type definitions for ForceFieldDebug component
 */

export interface ForceFieldDebugProps {
  // Component props
}
