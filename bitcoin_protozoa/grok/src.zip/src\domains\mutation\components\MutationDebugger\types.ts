/**
 * MutationDebugger Types
 *
 * @description Type definitions for MutationDebugger component
 */

export interface MutationDebuggerProps {
  // Component props
}
