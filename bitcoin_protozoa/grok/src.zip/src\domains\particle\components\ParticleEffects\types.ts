/**
 * Types for ParticleEffects component
 */
export interface ParticleEffectsProps {
  // Define props here
}
