/**
 * Types for BlockInfoPanel component
 */
export interface BlockInfoPanelProps {
  // Define props here
}
