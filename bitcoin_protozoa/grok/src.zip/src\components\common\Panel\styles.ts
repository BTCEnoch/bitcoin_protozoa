/**
 * Panel Styles
 *
 * @description Styles for Panel component
 */

export const useStyles = () => {
  return {
    container: {
      display: 'flex',
      flexDirection: 'column',
      padding: '1rem',
    },
  };
};
