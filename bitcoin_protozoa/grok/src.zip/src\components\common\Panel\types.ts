/**
 * Panel Types
 *
 * @description Type definitions for Panel component
 */

export interface PanelProps {
  // Component props
}
