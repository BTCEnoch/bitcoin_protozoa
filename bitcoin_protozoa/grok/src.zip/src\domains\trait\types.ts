/**
 * trait Types
 *
 * @description Type definitions for the trait domain
 */

/**
 * Placeholder interface for trait domain
 * TODO: Replace with actual types
 */
export interface traitConfig {
  // Add configuration properties here
  version: string;
}
