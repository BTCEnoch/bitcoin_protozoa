/**
 * Types for creatureService service
 */
export interface creatureServiceOptions {
  // Define options here
}
