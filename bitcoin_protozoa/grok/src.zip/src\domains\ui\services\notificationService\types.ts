/**
 * Types for notificationService service
 */
export interface notificationServiceOptions {
  // Define options here
}
