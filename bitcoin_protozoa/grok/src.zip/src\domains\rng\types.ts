/**
 * rng Types
 *
 * @description Type definitions for the rng domain
 */

/**
 * Placeholder interface for rng domain
 * TODO: Replace with actual types
 */
export interface rngConfig {
  // Add configuration properties here
  version: string;
}
