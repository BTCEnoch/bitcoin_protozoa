/**
 * Types for statsService service
 */
export interface statsServiceOptions {
  // Define options here
}
