/**
 * Types for roleService service
 */
export interface roleServiceOptions {
  // Define options here
}
