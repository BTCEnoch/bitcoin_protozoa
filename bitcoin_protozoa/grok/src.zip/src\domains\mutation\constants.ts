/**
 * mutation Constants
 *
 * @description Constants for the mutation domain
 */

/**
 * mutation version
 */
export const _VERSION = '0.1.0';
