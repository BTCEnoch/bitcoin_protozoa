/**
 * rng Constants
 *
 * @description Constants for the rng domain
 */

/**
 * rng version
 */
export const _VERSION = '0.1.0';
