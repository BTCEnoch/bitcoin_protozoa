/**
 * Types for traitCategoryService service
 */
export interface traitCategoryServiceOptions {
  // Define options here
}
