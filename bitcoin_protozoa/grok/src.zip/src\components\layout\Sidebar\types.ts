/**
 * Sidebar Types
 *
 * @description Type definitions for Sidebar component
 */

export interface SidebarProps {
  // Component props
}
