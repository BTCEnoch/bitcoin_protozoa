/**
 * Grid Types
 *
 * @description Type definitions for Grid component
 */

export interface GridProps {
  // Component props
}
