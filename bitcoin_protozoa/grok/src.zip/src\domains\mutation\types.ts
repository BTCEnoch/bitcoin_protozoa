/**
 * mutation Types
 *
 * @description Type definitions for the mutation domain
 */

/**
 * Placeholder interface for mutation domain
 * TODO: Replace with actual types
 */
export interface mutationConfig {
  // Add configuration properties here
  version: string;
}
