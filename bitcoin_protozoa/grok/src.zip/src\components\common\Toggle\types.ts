/**
 * Toggle Types
 *
 * @description Type definitions for Toggle component
 */

export interface ToggleProps {
  // Component props
}
