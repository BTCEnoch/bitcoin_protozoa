/**
 * Types for spatialService service
 */
export interface spatialServiceOptions {
  // Define options here
}
