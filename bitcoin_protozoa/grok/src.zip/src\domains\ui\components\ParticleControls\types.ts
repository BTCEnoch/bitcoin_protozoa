/**
 * ParticleControls Types
 *
 * @description Type definitions for ParticleControls component
 */

export interface ParticleControlsProps {
  // Component props
}
