/**
 * Chart Types
 *
 * @description Type definitions for Chart component
 */

export interface ChartProps {
  // Component props
}
