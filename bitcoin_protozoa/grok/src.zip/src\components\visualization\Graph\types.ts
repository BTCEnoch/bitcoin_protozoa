/**
 * Graph Types
 *
 * @description Type definitions for Graph component
 */

export interface GraphProps {
  // Component props
}
