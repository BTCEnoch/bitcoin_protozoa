/**
 * Button Types
 *
 * @description Type definitions for Button component
 */

export interface ButtonProps {
  // Component props
}
