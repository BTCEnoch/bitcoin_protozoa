/**
 * Types for MutationPanel component
 */
export interface MutationPanelProps {
  // Define props here
}
