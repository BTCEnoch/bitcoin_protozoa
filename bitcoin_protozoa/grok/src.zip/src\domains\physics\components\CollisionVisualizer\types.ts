/**
 * Types for CollisionVisualizer component
 */
export interface CollisionVisualizerProps {
  // Define props here
}
