/**
 * Types for purposeRngService service
 */
export interface purposeRngServiceOptions {
  // Define options here
}
