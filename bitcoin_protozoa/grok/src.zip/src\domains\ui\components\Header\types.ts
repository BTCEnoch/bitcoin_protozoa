/**
 * Header Types
 *
 * @description Type definitions for Header component
 */

export interface HeaderProps {
  // Component props
}
