/**
 * LogViewer Types
 *
 * @description Type definitions for LogViewer component
 */

export interface LogViewerProps {
  // Component props
}
