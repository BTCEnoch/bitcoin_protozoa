/**
 * Types for traitService service
 */
export interface traitServiceOptions {
  // Define options here
}
