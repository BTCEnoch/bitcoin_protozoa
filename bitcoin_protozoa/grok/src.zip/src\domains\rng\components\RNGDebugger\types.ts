/**
 * Types for RNGDebugger component
 */
export interface RNGDebuggerProps {
  // Define props here
}
