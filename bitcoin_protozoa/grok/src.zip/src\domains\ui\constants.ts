/**
 * ui Constants
 *
 * @description Constants for the ui domain
 */

/**
 * ui version
 */
export const _VERSION = '0.1.0';
