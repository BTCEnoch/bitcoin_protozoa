/**
 * Types for CreatureStats component
 */
export interface CreatureStatsProps {
  // Define props here
}
