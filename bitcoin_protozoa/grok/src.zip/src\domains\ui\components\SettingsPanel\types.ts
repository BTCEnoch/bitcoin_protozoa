/**
 * SettingsPanel Types
 *
 * @description Type definitions for SettingsPanel component
 */

export interface SettingsPanelProps {
  // Component props
}
