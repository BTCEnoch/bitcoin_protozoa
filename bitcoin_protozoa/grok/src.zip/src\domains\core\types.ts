/**
 * core Types
 *
 * @description Type definitions for the core domain
 */

/**
 * Placeholder interface for core domain
 * TODO: Replace with actual types
 */
export interface coreConfig {
  // Add configuration properties here
  version: string;
}
