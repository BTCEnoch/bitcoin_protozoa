/**
 * Types for ParticleCreature component
 */
export interface ParticleCreatureProps {
  // Define props here
}
