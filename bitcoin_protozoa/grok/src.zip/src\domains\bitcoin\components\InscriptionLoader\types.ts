/**
 * Types for InscriptionLoader component
 */
export interface InscriptionLoaderProps {
  // Define props here
}
