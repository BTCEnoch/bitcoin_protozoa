/**
 * Types for themeService service
 */
export interface themeServiceOptions {
  // Define options here
}
