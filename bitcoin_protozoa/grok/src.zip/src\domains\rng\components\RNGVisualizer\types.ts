/**
 * Types for RNGVisualizer component
 */
export interface RNGVisualizerProps {
  // Define props here
}
