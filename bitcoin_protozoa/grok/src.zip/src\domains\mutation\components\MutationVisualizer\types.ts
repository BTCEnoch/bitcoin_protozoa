/**
 * Types for MutationVisualizer component
 */
export interface MutationVisualizerProps {
  // Define props here
}
