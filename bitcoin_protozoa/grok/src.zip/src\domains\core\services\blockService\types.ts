/**
 * Types for blockService service
 */
export interface blockServiceOptions {
  // Define options here
}
