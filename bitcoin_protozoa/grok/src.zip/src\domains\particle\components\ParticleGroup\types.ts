/**
 * Types for ParticleGroup component
 */
export interface ParticleGroupProps {
  // Define props here
}
