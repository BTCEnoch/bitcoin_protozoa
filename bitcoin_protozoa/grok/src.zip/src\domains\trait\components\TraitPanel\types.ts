/**
 * Types for TraitPanel component
 */
export interface TraitPanelProps {
  // Define props here
}
