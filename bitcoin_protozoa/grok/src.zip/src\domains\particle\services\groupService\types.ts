/**
 * Types for groupService service
 */
export interface groupServiceOptions {
  // Define options here
}
