/**
 * Types for inscriptionService service
 */
export interface inscriptionServiceOptions {
  // Define options here
}
