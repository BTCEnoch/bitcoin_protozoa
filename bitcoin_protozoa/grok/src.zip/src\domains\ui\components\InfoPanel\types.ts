/**
 * InfoPanel Types
 *
 * @description Type definitions for InfoPanel component
 */

export interface InfoPanelProps {
  // Component props
}
