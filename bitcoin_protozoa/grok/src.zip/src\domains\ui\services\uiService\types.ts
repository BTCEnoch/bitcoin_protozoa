/**
 * Types for uiService service
 */
export interface uiServiceOptions {
  // Define options here
}
