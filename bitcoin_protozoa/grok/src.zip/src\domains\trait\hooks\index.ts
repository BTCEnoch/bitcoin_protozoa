/**
 * trait Hooks
 *
 * @description Hook exports for the trait domain
 */

// Export all hooks
