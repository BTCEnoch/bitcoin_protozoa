/**
 * Footer Types
 *
 * @description Type definitions for Footer component
 */

export interface FooterProps {
  // Component props
}
