/**
 * Types for collisionService service
 */
export interface collisionServiceOptions {
  // Define options here
}
