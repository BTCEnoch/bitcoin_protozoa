/**
 * ParticleDebug Types
 *
 * @description Type definitions for ParticleDebug component
 */

export interface ParticleDebugProps {
  // Component props
}
