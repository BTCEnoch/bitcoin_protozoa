/**
 * TraitDebugger Types
 *
 * @description Type definitions for TraitDebugger component
 */

export interface TraitDebuggerProps {
  // Component props
}
