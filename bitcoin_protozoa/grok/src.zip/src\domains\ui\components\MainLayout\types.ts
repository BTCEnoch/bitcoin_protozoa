/**
 * MainLayout Types
 *
 * @description Type definitions for MainLayout component
 */

export interface MainLayoutProps {
  // Component props
}
