/**
 * trait Constants
 *
 * @description Constants for the trait domain
 */

/**
 * trait version
 */
export const _VERSION = '0.1.0';
