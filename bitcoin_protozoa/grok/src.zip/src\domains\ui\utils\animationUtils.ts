/**
 * animationUtils Utilities
 *
 * @description Utility functions for animationUtils
 */

/**
 * Example utility function
 */
export const exampleUtil = () => {
  // Utility implementation
};
