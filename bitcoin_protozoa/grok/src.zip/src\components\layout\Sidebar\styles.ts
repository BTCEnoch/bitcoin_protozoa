/**
 * Sidebar Styles
 *
 * @description Styles for Sidebar component
 */

export const useStyles = () => {
  return {
    container: {
      display: 'flex',
      flexDirection: 'column',
      padding: '1rem',
    },
  };
};
