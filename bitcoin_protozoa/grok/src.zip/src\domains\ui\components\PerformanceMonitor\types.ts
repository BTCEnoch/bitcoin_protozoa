/**
 * PerformanceMonitor Types
 *
 * @description Type definitions for PerformanceMonitor component
 */

export interface PerformanceMonitorProps {
  // Component props
}
