/**
 * Container Types
 *
 * @description Type definitions for Container component
 */

export interface ContainerProps {
  // Component props
}
