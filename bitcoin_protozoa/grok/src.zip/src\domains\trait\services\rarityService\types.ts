/**
 * Types for rarityService service
 */
export interface rarityServiceOptions {
  // Define options here
}
