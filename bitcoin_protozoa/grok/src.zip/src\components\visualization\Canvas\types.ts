/**
 * Canvas Types
 *
 * @description Type definitions for Canvas component
 */

export interface CanvasProps {
  // Component props
}
