/**
 * Types for mutationService service
 */
export interface mutationServiceOptions {
  // Define options here
}
