/**
 * Types for ForceFieldVisualizer component
 */
export interface ForceFieldVisualizerProps {
  // Define props here
}
