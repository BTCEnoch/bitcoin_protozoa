/**
 * Slider Types
 *
 * @description Type definitions for Slider component
 */

export interface SliderProps {
  // Component props
}
