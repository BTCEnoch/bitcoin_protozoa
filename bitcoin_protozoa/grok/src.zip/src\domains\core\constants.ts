/**
 * core Constants
 *
 * @description Constants for the core domain
 */

/**
 * core version
 */
export const _VERSION = '0.1.0';
