/**
 * Types for milestoneService service
 */
export interface milestoneServiceOptions {
  // Define options here
}
