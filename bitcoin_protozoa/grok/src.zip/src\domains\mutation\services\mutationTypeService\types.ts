/**
 * Types for mutationTypeService service
 */
export interface mutationTypeServiceOptions {
  // Define options here
}
