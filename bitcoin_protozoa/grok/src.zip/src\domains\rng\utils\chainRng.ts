/**
 * chainRng Utilities
 *
 * @description Utility functions for chainRng
 */

/**
 * Example utility function
 */
export const exampleUtil = () => {
  // Utility implementation
};
