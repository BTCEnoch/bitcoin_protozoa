/**
 * Types for forceFieldService service
 */
export interface forceFieldServiceOptions {
  // Define options here
}
